-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 26 2019 г., 10:18
-- Версия сервера: 5.7.26
-- Версия PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `user_admnistration`
--

-- --------------------------------------------------------

--
-- Структура таблицы `trainers_has_clients`
--

DROP TABLE IF EXISTS `trainers_has_clients`;
CREATE TABLE IF NOT EXISTS `trainers_has_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_trainer` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `trainers_has_clients`
--

INSERT INTO `trainers_has_clients` (`id`, `id_trainer`, `id_user`) VALUES
(1, 1, 2),
(2, 1, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `trainings`
--

DROP TABLE IF EXISTS `trainings`;
CREATE TABLE IF NOT EXISTS `trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_coach` int(11) DEFAULT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `created_ts` int(11) DEFAULT NULL,
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `trainings`
--

INSERT INTO `trainings` (`id`, `id_coach`, `id_user`, `title`, `description`, `created_ts`, `start_ts`, `end_ts`) VALUES
(52, 1, 3, 'Lorem', 'Ipsum', 1566762017, 1567065000, 1567072800),
(53, 1, 2, 'Nowe zdarzenie', '', 1566762017, 1566892200, 1566900000),
(54, 1, 2, 'test', 'test', 1566762017, 1566978600, 1566986400),
(55, 1, 2, 'test', 'test', 1566811544, 1564657200, 1564668000);

-- --------------------------------------------------------

--
-- Структура таблицы `trainings_notes`
--

DROP TABLE IF EXISTS `trainings_notes`;
CREATE TABLE IF NOT EXISTS `trainings_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_training` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `created_ts` int(11) NOT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `trainings_notes`
--

INSERT INTO `trainings_notes` (`id`, `id_training`, `title`, `description`, `created_ts`, `public`) VALUES
(1, 17, 'test', 'test', 1566750202, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_trainer` int(11) DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `avatar_image` varchar(255) DEFAULT NULL,
  `description` text,
  `experience` text,
  `type` enum('user','coach','both','manager') CHARACTER SET latin1 NOT NULL DEFAULT 'user',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `premium_ts` int(11) DEFAULT NULL,
  `created_ts` int(11) NOT NULL,
  `edited_ts` int(11) DEFAULT NULL,
  `activation_token` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `active_token` tinyint(4) NOT NULL DEFAULT '0',
  `email_notification` tinyint(1) NOT NULL DEFAULT '0',
  `sms_notification` tinyint(1) NOT NULL DEFAULT '0',
  `time_notification` int(11) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `id_trainer`, `email`, `nick_name`, `password`, `first_name`, `last_name`, `address`, `phone`, `avatar_image`, `description`, `experience`, `type`, `active`, `premium_ts`, `created_ts`, `edited_ts`, `activation_token`, `active_token`, `email_notification`, `sms_notification`, `time_notification`, `admin`) VALUES
(1, 0, 'test@test.com', 'Test', '05a671c66aefea124cc08b76ea6d30bb', 'Ivan', 'Lyadov', '', '1233213', '1566811312_4645_7545.jpg', 'Lorem isum', 'Lorem ipsum', 'coach', 1, 0, 0, 1566811312, 'b42061edcdfaf62f3993891a9c2f47055c805257498e6b86092fd279a3b3eeeb', 1, 0, 0, 0, 1),
(2, NULL, 'client_test@test.com', NULL, 'eca7266f2576ff9d5c251735b675c99b', 'Client_test', 'Client_test', NULL, '123312123', NULL, NULL, NULL, 'user', 1, NULL, 1566735402, NULL, 'b0193ff54c07073727d277b0375a00462e6ddd7ad6815454e6afc406e86939c1', 0, 0, 0, NULL, 0),
(3, NULL, 'client_two@test.com', NULL, '70b4321325d9d63705be33d7bba8c15f', 'Client_first_name', 'Client_Last_name', NULL, '123312123', NULL, NULL, NULL, 'user', 1, NULL, 1566739202, NULL, '2b82604ef6fd975bf09c152bbfce2e4e4ebf017dc8f8ce54ff5195ef5b239d9d', 0, 0, 0, NULL, 0),
(4, NULL, 'tetst@tests.dfsdfsd', NULL, '5b881c694ba4b7b28b1929d14f2b863c', 'tsefdf', 'fsdfds', NULL, '123123123', NULL, NULL, NULL, 'user', 1, NULL, 1566751004, NULL, 'b403bbd08294c40a2802f1eb63b4614a1b8c271f416c4cc67588a7e01d60c825', 0, 0, 0, NULL, 0),
(5, NULL, 'tet@kdjlsj.com', NULL, 'f3c6956bd4a58bce41b0d87fad40b45d', 'tslfs', 'jdlf', NULL, '132323213', NULL, NULL, NULL, 'user', 1, NULL, 1566760907, NULL, 'dd339aeabbce3d820cf2099da687eda63970308c68f39f34ae17570cfcc3e519', 0, 0, 0, NULL, 0),
(6, NULL, 'dokaperi7@gmail.com', NULL, '318749533d17b3cd2e9aa86d0cb83965', 'John', 'Brenn', NULL, '123321123', NULL, NULL, NULL, 'coach', 1, NULL, 1566761428, 1566761553, '212df5d104d449562e8a977aee6c3cf7b6e1b9520ed8cd712e19b2d0363bfee6', 0, 0, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users_images`
--

DROP TABLE IF EXISTS `users_images`;
CREATE TABLE IF NOT EXISTS `users_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `user_tasks`
--

DROP TABLE IF EXISTS `user_tasks`;
CREATE TABLE IF NOT EXISTS `user_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `is_open` tinyint(4) DEFAULT NULL,
  `day_start_ts` int(11) DEFAULT NULL,
  `day_end_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_tasks`
--

INSERT INTO `user_tasks` (`id`, `id_user`, `title`, `description`, `is_open`, `day_start_ts`, `day_end_ts`) VALUES
(9, 1, 'Test', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 1, 1566856800, 1566943199),
(10, 1, 'Test 2', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ', 1, 1566943200, 1567029599),
(11, 1, 'test', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 1, 1566770400, 1566856799);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
